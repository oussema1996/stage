# -*- coding: utf-8 -*-

from odoo import models, fields, api
class sales_order_famo(models.Model):
    _inherit ='sale.order' # Le Nom de votre Module qui genere les sale_order, il doit etre installer avant d'installer ce module herité
    bank_account=fields.Selection([ ('Dollars-bank-account', 'Dollars-bank-account'),('Euros-bank-account', 'Euros-bank-account'),],'Bank account', default='Euros-bank-account',translate=True)


