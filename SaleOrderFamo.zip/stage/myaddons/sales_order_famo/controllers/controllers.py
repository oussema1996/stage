# -*- coding: utf-8 -*-
from odoo import http

# class SalesOrderFamo(http.Controller):
#     @http.route('/sales_order_famo/sales_order_famo/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/sales_order_famo/sales_order_famo/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('sales_order_famo.listing', {
#             'root': '/sales_order_famo/sales_order_famo',
#             'objects': http.request.env['sales_order_famo.sales_order_famo'].search([]),
#         })

#     @http.route('/sales_order_famo/sales_order_famo/objects/<model("sales_order_famo.sales_order_famo"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('sales_order_famo.object', {
#             'object': obj
#         })